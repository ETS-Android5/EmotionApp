class BatchNorm2d(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = ["running_mean", "running_var", "num_batches_tracked", ]
  weight : Tensor
  bias : Tensor
  running_mean : Tensor
  running_var : Tensor
  num_batches_tracked : Tensor
  training : bool
  def forward(self: __torch__.torch.nn.modules.batchnorm.___torch_mangle_282.BatchNorm2d,
    input: Tensor) -> Tensor:
    _0 = self.running_var
    _1 = self.running_mean
    _2 = self.bias
    input0 = torch.batch_norm(input, self.weight, _2, _1, _0, False, 0.10000000000000001, 1.0000000000000001e-05, True)
    return input0
